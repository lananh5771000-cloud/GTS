"""Giải hệ tuyến tính bằng phương pháp Gauss–Seidel (Seidel).

Nguyên tắc của bản này:
- Nghiệm chỉ được tạo bởi các bước lặp Gauss–Seidel.
- Không dùng solve/inv/eig/cholesky/rank/det của NumPy để lấy nghiệm hoặc
  để che giấu một phương pháp trực tiếp khác.
- Chỉ khẳng định sai số nghiệm khi có chặn co hợp lệ.
- Với ma trận chéo trội cột, đặt y_i=a_ii*x_i và dùng một chuẩn 1 có
  trọng số để xây dựng chặn hậu nghiệm đúng.
"""

import math
from exam_format import exam_print as print
from input_utils import parse_real as parse_input_real
import sys
from fractions import Fraction
from itertools import permutations

import numpy as np

try:
    import sympy as sp
except ImportError:
    sp = None


ZERO_TOL = 1e-14
HUGE_VALUE = 1e100
DISPLAY_FRACTIONS = False


# ============================================================================
# NHẬP VÀ HIỂN THỊ
# ============================================================================


def parse_number(text):
    text = text.strip()
    if not text:
        raise ValueError("Thiếu giá trị.")
    try:
        if sp is not None:
            value = sp.Float(parse_input_real(text))
            if value.is_real is False or value.free_symbols:
                raise ValueError(f"'{text}' không phải số thực.")
            result = float(value.evalf())
        elif "/" in text:
            result = parse_input_real(text)
        else:
            result = float(text)
    except (TypeError, ValueError, ZeroDivisionError, SyntaxError) as exc:
        raise ValueError(f"Không đọc được số '{text}'.") from exc
    if not math.isfinite(result):
        raise ValueError("Không chấp nhận NaN hoặc vô cùng.")
    return result


def parse_numbers(line, expected):
    parts = line.split()
    if len(parts) != expected:
        raise ValueError(f"Cần đúng {expected} phần tử, đã nhận {len(parts)}.")
    return np.array([parse_number(item) for item in parts], dtype=float)


def read_int(prompt, minimum=1, default=None):
    while True:
        raw = input(prompt).strip()
        if not raw and default is not None:
            return default
        try:
            value = int(raw)
            if value >= minimum:
                return value
        except ValueError:
            pass
        print(f"  Lỗi: cần số nguyên >= {minimum}.")


def read_float(prompt, positive=False, default=None):
    while True:
        raw = input(prompt).strip()
        if not raw and default is not None:
            return default
        try:
            value = parse_number(raw)
            if not positive or value > 0:
                return value
        except ValueError as exc:
            print(f"  Lỗi: {exc}")
            continue
        print("  Lỗi: giá trị phải dương.")


def read_vector(n, prompt, default=None):
    while True:
        raw = input(prompt).strip()
        if not raw and default is not None:
            return np.full(n, default, dtype=float)
        try:
            return parse_numbers(raw, n)
        except ValueError as exc:
            print(f"  Lỗi: {exc}")


def read_matrix(rows, columns, name):
    print(f"Nhập ma trận {name} kích thước {rows}x{columns}:")
    result = []
    for i in range(rows):
        while True:
            try:
                result.append(parse_numbers(input(f"  Hàng {i + 1}: "), columns))
                break
            except ValueError as exc:
                print(f"  Lỗi: {exc}")
    return np.vstack(result)


def _display_number(value, precision):
    value = float(value)
    threshold = 0.5 * 10.0 ** (-precision) if precision > 0 else 0.5
    if abs(value) < threshold:
        value = 0.0
    if DISPLAY_FRACTIONS:
        return str(Fraction(value).limit_denominator(10000))
    if value != 0 and (
        abs(value) >= 10 ** (precision + 2) or abs(value) < 10 ** (-max(precision, 1))
    ):
        return f"{value:.{precision}e}"
    return f"{value:.{precision}f}"


def print_matrix(name, matrix, precision=6):
    array = np.asarray(matrix, dtype=float)
    rows = array.reshape(-1, 1) if array.ndim == 1 else array
    texts = [[_display_number(value, precision) for value in row] for row in rows]
    width = max(10, max(len(item) for row in texts for item in row) + 1)
    print(f"{name} =")
    for row in texts:
        print("  [" + " ".join(item.rjust(width) for item in row) + "]")


def format_table_number(value, precision):
    return _display_number(value, precision)


# ============================================================================
# PHÉP TOÁN PHỤ TRỢ – KHÔNG DÙNG BỘ GIẢI HỆ CÓ SẴN
# ============================================================================


def validate_system(a, b=None):
    a = np.asarray(a, dtype=float)
    if a.ndim != 2 or a.shape[0] == 0 or a.shape[0] != a.shape[1]:
        raise ValueError("A phải là ma trận vuông cấp n>0.")
    if not np.all(np.isfinite(a)):
        raise ValueError("A chứa NaN hoặc vô cùng.")
    if b is not None:
        b = np.asarray(b, dtype=float)
        if b.shape != (len(a),) or not np.all(np.isfinite(b)):
            raise ValueError("b sai kích thước hoặc chứa NaN/vô cùng.")


def forward_substitution(lower, rhs):
    """Giải hệ tam giác dưới L X=R bằng thế tiến."""
    lower = np.asarray(lower, dtype=float)
    rhs = np.asarray(rhs, dtype=float)
    n = lower.shape[0]
    if lower.shape != (n, n):
        raise ValueError("Ma trận thế tiến phải vuông.")
    vector_rhs = rhs.ndim == 1
    work = rhs.reshape(n, 1).copy() if vector_rhs else rhs.copy()
    if work.ndim != 2 or work.shape[0] != n:
        raise ValueError("Vế phải của phép thế tiến sai kích thước.")
    result = np.zeros_like(work, dtype=float)
    scale = max(1.0, float(np.max(np.abs(lower))))
    for i in range(n):
        pivot = lower[i, i]
        if abs(pivot) <= ZERO_TOL * scale:
            raise ArithmeticError("Phần tử chéo của hệ tam giác bằng hoặc quá gần 0.")
        result[i] = (work[i] - lower[i, :i] @ result[:i]) / pivot
    return result[:, 0] if vector_rhs else result


def iteration_matrix(a):
    """T=-(D+L_A)^(-1)U_A, được tính bằng thế tiến."""
    a = np.asarray(a, dtype=float)
    return forward_substitution(np.tril(a), -np.triu(a, 1))


def iteration_vector(a, b):
    """g=(D+L_A)^(-1)b, được tính bằng thế tiến."""
    return forward_substitution(np.tril(a), np.asarray(b, dtype=float))


def matrix_norm_inf(matrix):
    matrix = np.asarray(matrix, dtype=float)
    return float(np.max(np.sum(np.abs(matrix), axis=1)))


def vector_norm_inf(vector):
    return float(np.max(np.abs(np.asarray(vector, dtype=float))))


def relative_residual(a, x, b):
    residual = np.asarray(b) - np.asarray(a) @ np.asarray(x)
    numerator = vector_norm_inf(residual)
    denominator = matrix_norm_inf(a) * vector_norm_inf(x) + vector_norm_inf(b)
    if denominator == 0:
        return 0.0 if numerator == 0 else math.inf
    return numerator / denominator


def row_dominance_margins(a):
    diagonal = np.abs(np.diag(a))
    return diagonal - (np.sum(np.abs(a), axis=1) - diagonal)


def column_dominance_margins(a):
    diagonal = np.abs(np.diag(a))
    return diagonal - (np.sum(np.abs(a), axis=0) - diagonal)


def dominance_kind(margins):
    margins = np.asarray(margins, dtype=float)
    if np.all(margins > ZERO_TOL):
        return "chéo trội nghiêm ngặt"
    if np.all(margins >= -ZERO_TOL):
        return "chéo trội không nghiêm ngặt"
    return "không chéo trội"


def ldlt_spd_certificate(a):
    """Kiểm tra SPD bằng phân tích LDL^T tự cài đặt, không dùng Cholesky có sẵn."""
    a = np.asarray(a, dtype=float)
    n = len(a)
    scale = max(1.0, float(np.max(np.abs(a))))
    symmetric = np.allclose(a, a.T, rtol=1e-11, atol=1e-13 * scale)
    result = {
        "symmetric": symmetric,
        "spd": False,
        "L": None,
        "D": None,
        "leading_determinants": [],
    }
    if not symmetric:
        return result

    l_matrix = np.eye(n)
    d_vector = np.zeros(n)
    determinants = []
    product = 1.0
    for j in range(n):
        pivot = a[j, j] - math.fsum(
            l_matrix[j, k] * l_matrix[j, k] * d_vector[k] for k in range(j)
        )
        if not math.isfinite(pivot) or pivot <= ZERO_TOL * scale:
            return result
        d_vector[j] = pivot
        product *= pivot
        determinants.append(product)
        for i in range(j + 1, n):
            numerator = a[i, j] - math.fsum(
                l_matrix[i, k] * l_matrix[j, k] * d_vector[k] for k in range(j)
            )
            l_matrix[i, j] = numerator / pivot
    result.update(spd=True, L=l_matrix, D=d_vector, leading_determinants=determinants)
    return result


def sassenfeld_coefficients(a):
    """Hệ số Sassenfeld theo thứ tự cập nhật từ 1 đến n."""
    a = np.asarray(a, dtype=float)
    n = len(a)
    beta = np.zeros(n)
    for i in range(n):
        denominator = abs(a[i, i])
        if denominator <= ZERO_TOL:
            return beta, math.inf
        lower = math.fsum(abs(a[i, j]) * beta[j] for j in range(i))
        upper = math.fsum(abs(a[i, j]) for j in range(i + 1, n))
        beta[i] = (lower + upper) / denominator
    return beta, float(np.max(beta))


def column_weighted_certificate(a):
    """Chứng nhận co cho nhánh y_i=a_ii*x_i.

    C=I-A D^(-1), C=L+U. Đặt
        ell_j = sum_{i>j}|c_ij|,
        u_j   = sum_{i<j}|c_ij|,
        w_j   = 1-ell_j,
        q     = max_j u_j/w_j.
    Nếu q<1 thì Gauss–Seidel là ánh xạ co theo chuẩn
        ||z||_w = sum_j w_j|z_j|.
    """
    a = np.asarray(a, dtype=float)
    diagonal = np.diag(a)
    if np.any(np.abs(diagonal) <= ZERO_TOL):
        return None
    c_matrix = np.eye(len(a)) - a @ np.diag(1.0 / diagonal)
    lower = np.tril(c_matrix, -1)
    upper = np.triu(c_matrix, 1)
    ell = np.sum(np.abs(lower), axis=0)
    upper_column = np.sum(np.abs(upper), axis=0)
    weights = 1.0 - ell
    if np.any(weights <= ZERO_TOL):
        return {
            "valid": False,
            "C": c_matrix,
            "L": lower,
            "U": upper,
            "weights": weights,
            "ell": ell,
            "u": upper_column,
            "q": math.inf,
            "scale_to_x_inf": math.inf,
        }
    ratios = upper_column / weights
    q_value = float(np.max(ratios))
    scale_to_x_inf = 1.0 / float(np.min(weights * np.abs(diagonal)))
    return {
        "valid": math.isfinite(q_value) and q_value < 1.0,
        "C": c_matrix,
        "L": lower,
        "U": upper,
        "weights": weights,
        "ell": ell,
        "u": upper_column,
        "q": q_value,
        "scale_to_x_inf": scale_to_x_inf,
    }


def weighted_one_norm(vector, weights):
    return float(np.sum(np.asarray(weights) * np.abs(np.asarray(vector))))


# ============================================================================
# CHỌN THỨ TỰ PHƯƠNG TRÌNH
# ============================================================================


def _candidate_analysis(a):
    diagonal = np.diag(a)
    if np.any(np.abs(diagonal) <= ZERO_TOL):
        return None
    try:
        t_matrix = iteration_matrix(a)
    except ArithmeticError:
        return None
    q_x = matrix_norm_inf(t_matrix)
    row_margins = row_dominance_margins(a)
    col_margins = column_dominance_margins(a)
    row_dom = bool(np.all(row_margins > ZERO_TOL))
    col_dom = bool(np.all(col_margins > ZERO_TOL))
    col_data = column_weighted_certificate(a)
    q_y = col_data["q"] if col_data is not None else math.inf
    certified_values = [q for q in (q_x, q_y) if math.isfinite(q) and q < 1]
    best_q = min(certified_values) if certified_values else min(q_x, q_y)
    return {
        "q_x": q_x,
        "q_y": q_y,
        "best_q": best_q,
        "certified": bool(certified_values),
        "row_dom": row_dom,
        "col_dom": col_dom,
        "dominance_sum": float(np.sum(row_margins)),
    }


def _candidate_rank(item):
    return (
        0 if item["certified"] else 1,
        item["best_q"],
        0 if item["row_dom"] else (1 if item["col_dom"] else 2),
        -item["dominance_sum"],
        item["changes"],
    )


def _greedy_nonzero_diagonal(a):
    """Ghép mỗi cột với một hàng có hệ số lớn, chỉ dùng khi n lớn."""
    n = len(a)
    choices = [list(np.argsort(-np.abs(a[:, column]))) for column in range(n)]
    column_to_row = np.full(n, -1, dtype=int)

    def augment(column, seen):
        for row in choices[column]:
            row = int(row)
            if abs(a[row, column]) <= ZERO_TOL or row in seen:
                continue
            seen.add(row)
            old = np.where(column_to_row == row)[0]
            if old.size == 0 or augment(int(old[0]), seen):
                column_to_row[column] = row
                return True
        return False

    for column in range(n):
        if not augment(column, set()):
            return None
    return column_to_row


def find_best_row_permutation(a, max_local_rounds=6):
    n = len(a)
    evaluated = []

    def add(permutation, source):
        permutation = np.asarray(permutation, dtype=int)
        data = _candidate_analysis(a[permutation])
        if data is None:
            return
        data.update(
            permutation=permutation.copy(),
            source=source,
            changes=int(np.count_nonzero(permutation != np.arange(n))),
        )
        evaluated.append(data)

    if n <= 8:
        for permutation in permutations(range(n)):
            add(permutation, "vét cạn")
        method = f"vét cạn {math.factorial(n)} hoán vị hàng"
    else:
        identity = np.arange(n)
        add(identity, "thứ tự ban đầu")
        seed = _greedy_nonzero_diagonal(a)
        if seed is not None:
            add(seed, "ghép đường chéo")
        active = [identity] + ([seed] if seed is not None else [])
        for round_index in range(max_local_rounds):
            next_active = []
            for base in active[:4]:
                local = []
                for i in range(n - 1):
                    for j in range(i + 1, n):
                        candidate = np.array(base, dtype=int)
                        candidate[i], candidate[j] = candidate[j], candidate[i]
                        data = _candidate_analysis(a[candidate])
                        if data is not None:
                            data.update(
                                permutation=candidate.copy(),
                                source=f"đổi cặp vòng {round_index + 1}",
                                changes=int(
                                    np.count_nonzero(candidate != np.arange(n))
                                ),
                            )
                            evaluated.append(data)
                            local.append(data)
                if local:
                    next_active.append(min(local, key=_candidate_rank)["permutation"])
            if not next_active:
                break
            active = next_active
        method = "ghép đường chéo và tìm cục bộ bằng đổi cặp hàng"

    if not evaluated:
        return None, method, []
    evaluated.sort(key=_candidate_rank)
    return evaluated[0], method, evaluated[:5]


def prepare_system(a, b, auto_reorder=True):
    validate_system(a, b)
    a = np.asarray(a, dtype=float).copy()
    b = np.asarray(b, dtype=float).copy()
    n = len(a)
    identity = np.arange(n)
    original_spd = ldlt_spd_certificate(a)["spd"]
    original = _candidate_analysis(a)

    info = {
        "permutation": identity,
        "reordered": False,
        "reason": "Giữ nguyên thứ tự phương trình.",
        "method": "không tìm",
        "top_candidates": [],
        "spd_original": original_spd,
    }

    if original_spd:
        info["reason"] = "A là SPD; không đổi riêng hàng để tránh phá tính đối xứng."
    elif auto_reorder:
        best, method, top = find_best_row_permutation(a)
        info["method"] = method
        info["top_candidates"] = top
        if best is None:
            raise ValueError("Không tìm được thứ tự hàng có đường chéo khác 0.")
        changed = not np.array_equal(best["permutation"], identity)
        original_certified = original is not None and original["certified"]
        original_q = original["best_q"] if original is not None else math.inf
        accept = False
        if original is None:
            accept = changed
            reason = "Đổi hàng để tạo đường chéo khác 0."
        elif best["certified"] and not original_certified:
            accept = changed
            reason = "Đổi hàng vì tìm được một chứng nhận co q<1."
        elif (
            best["certified"]
            and original_certified
            and best["best_q"] < original_q - 1e-12
        ):
            accept = changed
            reason = "Đổi hàng vì hệ số co được cải thiện."
        else:
            reason = (
                "Không đổi hàng vì không có phương án tốt hơn về chứng nhận hội tụ."
            )
        if accept:
            permutation = best["permutation"]
            a = a[permutation]
            b = b[permutation]
            info.update(permutation=permutation, reordered=True, reason=reason)
        else:
            info["reason"] = reason
    else:
        info["reason"] = "Người dùng tắt tự động đổi hàng."

    if np.any(np.abs(np.diag(a)) <= ZERO_TOL):
        raise ValueError("Đường chéo có phần tử bằng hoặc quá gần 0.")
    return a, b, info


# ============================================================================
# PHÂN TÍCH VÀ LẶP SEIDEL
# ============================================================================


def build_iteration_analysis(a, b):
    n = len(a)
    diagonal = np.diag(a)
    row_margins = row_dominance_margins(a)
    col_margins = column_dominance_margins(a)
    row_dom = bool(np.all(row_margins > ZERO_TOL))
    col_dom = bool(np.all(col_margins > ZERO_TOL))
    spd_data = ldlt_spd_certificate(a)

    d_matrix = np.diag(diagonal)
    lower_a = np.tril(a, -1)
    upper_a = np.triu(a, 1)
    t_direct = iteration_matrix(a)
    g_direct = iteration_vector(a, b)
    q_direct = matrix_norm_inf(t_direct)
    beta, q_sassenfeld = sassenfeld_coefficients(a)
    column_data = column_weighted_certificate(a)

    if row_dom:
        variable = "x"
        method = "Seidel trực tiếp (chéo trội hàng)"
    elif col_dom and column_data is not None and column_data["valid"]:
        variable = "y"
        method = "Seidel sau đổi biến y_i=a_ii x_i (chéo trội cột)"
    elif q_direct < 1:
        variable = "x"
        method = "Seidel trực tiếp với ||T||∞<1"
    elif column_data is not None and column_data["valid"]:
        variable = "y"
        method = "Seidel đổi biến với chuẩn 1 có trọng số"
    else:
        variable = "x"
        method = "Seidel tổng quát (chưa có chặn co)"

    if variable == "x":
        c_matrix = np.eye(n) - np.diag(1.0 / diagonal) @ a
        lower = np.tril(c_matrix, -1)
        upper = np.triu(c_matrix, 1)
        d_vector = b / diagonal
        theory = None
        if q_direct < 1:
            theory = {
                "kind": "x_inf",
                "q": q_direct,
                "coefficient": q_direct / (1 - q_direct),
                "description": "chuẩn vô cùng của ma trận lặp T",
            }
    else:
        c_matrix = column_data["C"]
        lower = column_data["L"]
        upper = column_data["U"]
        d_vector = b.copy()
        q_value = column_data["q"]
        theory = {
            "kind": "y_weighted",
            "q": q_value,
            "coefficient": q_value / (1 - q_value),
            "weights": column_data["weights"],
            "scale_to_x_inf": column_data["scale_to_x_inf"],
            "description": "chuẩn 1 có trọng số của biến y",
        }

    return {
        "method": method,
        "variable": variable,
        "D": d_matrix,
        "L_A": lower_a,
        "U_A": upper_a,
        "T": t_direct,
        "g": g_direct,
        "q_direct": q_direct,
        "beta": beta,
        "q_sassenfeld": q_sassenfeld,
        "C": c_matrix,
        "L": lower,
        "U": upper,
        "d": d_vector,
        "row_margins": row_margins,
        "col_margins": col_margins,
        "row_dom": row_dom,
        "col_dom": col_dom,
        "spd": spd_data["spd"],
        "spd_data": spd_data,
        "column_data": column_data,
        "theory": theory,
    }


def estimate_apriori_iterations(q, first_difference, scale, epsilon):
    """Tìm k sao cho scale*q^k/(1-q)*first_difference <= epsilon."""
    if not (0 <= q < 1) or first_difference < 0 or scale <= 0:
        return None
    if first_difference == 0:
        return 0
    if q == 0:
        return 1
    target = epsilon * (1 - q) / (scale * first_difference)
    if target >= 1:
        return 0
    if target <= 0 or not math.isfinite(target):
        return None
    try:
        result = max(0, math.ceil(math.log(target) / math.log(q)))
        while scale * q**result / (1 - q) * first_difference > epsilon:
            result += 1
        return result
    except (ValueError, OverflowError, ZeroDivisionError):
        return None


def _diagnose(xs, residuals, epsilon):
    if len(xs) >= 6:
        recent = [
            vector_norm_inf(xs[i] - xs[i - 1]) for i in range(len(xs) - 4, len(xs))
        ]
        machine = 100 * np.finfo(float).eps * max(1.0, vector_norm_inf(xs[-1]))
        if max(recent) <= machine and residuals[-1] > epsilon:
            return "Đình trệ do giới hạn số học máy."
    if len(residuals) >= 7 and all(
        residuals[i] > 1.2 * residuals[i - 1]
        for i in range(len(residuals) - 5, len(residuals))
    ):
        return "Phần dư tăng liên tiếp; phép lặp có dấu hiệu phân kỳ."
    if len(xs) >= 7:
        norms = [vector_norm_inf(value) for value in xs[-6:]]
        if norms[0] > 0 and all(
            norms[i] > 2 * norms[i - 1] for i in range(1, len(norms))
        ):
            return "Chuẩn vector lặp tăng rất nhanh; phép lặp có dấu hiệu phân kỳ."
    return None


def gauss_seidel(
    a,
    b,
    x0=None,
    epsilon=1e-6,
    max_iter=500,
    precision=6,
    auto_reorder=True,
    show=True,
    fixed_iterations=None,
    use_inverse_bound=False,
    residual_tolerance=None,
    show_y=False,
    numpy_check=False,
    stop_mode="posteriori",
):
    """Giải Ax=b bằng đúng phép lặp Gauss–Seidel."""
    del use_inverse_bound, numpy_check  # giữ tham số để tương thích bản cũ
    if stop_mode not in {"posteriori", "apriori"}:
        raise ValueError("stop_mode phải là 'posteriori' hoặc 'apriori'.")
    if not math.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("epsilon phải là số hữu hạn dương.")
    if not isinstance(max_iter, (int, np.integer)) or max_iter <= 0:
        raise ValueError("max_iter phải là số nguyên dương.")
    if fixed_iterations is not None and (
        not isinstance(fixed_iterations, (int, np.integer)) or fixed_iterations < 0
    ):
        raise ValueError("fixed_iterations phải là số nguyên không âm.")
    if residual_tolerance is None:
        residual_tolerance = epsilon
    if not math.isfinite(residual_tolerance) or residual_tolerance <= 0:
        raise ValueError("residual_tolerance phải dương.")

    a_original = np.asarray(a, dtype=float)
    b_original = np.asarray(b, dtype=float)
    a, b, prep = prepare_system(a_original, b_original, auto_reorder)
    n = len(a)
    x = np.zeros(n) if x0 is None else np.asarray(x0, dtype=float).copy()
    if x.shape != (n,) or not np.all(np.isfinite(x)):
        raise ValueError("x0 sai kích thước hoặc chứa NaN/vô cùng.")

    analysis = build_iteration_analysis(a, b)
    diagonal = np.diag(a)
    y = diagonal * x if analysis["variable"] == "y" else x.copy()
    theory = analysis["theory"]
    if fixed_iterations is None and stop_mode == "apriori" and theory is None:
        raise ValueError(
            "Không lập được chặn tiên nghiệm vì chưa có hệ số co q<1 trong chuẩn đang dùng. "
            "Ma trận vẫn có thể hội tụ theo điều kiện khác (ví dụ SPD), nhưng công thức tiên nghiệm này không áp dụng."
        )

    if show:
        print("\n" + "=" * 92)
        print("GIẢI HỆ BẰNG PHƯƠNG PHÁP GAUSS–SEIDEL")
        print("=" * 92)
        print("\nPHẦN 1. DỮ LIỆU")
        print_matrix("A", a_original, precision)
        print_matrix("b", b_original, precision)
        print_matrix("x^(0)", x, precision)
        if fixed_iterations is None:
            print(f"Yêu cầu: sai số epsilon = {epsilon:.{precision}e}.")
        else:
            print(f"Yêu cầu: thực hiện đúng k={fixed_iterations} bước.")

        print("\nPHẦN 2. KIỂM TRA ĐIỀU KIỆN")
        if prep["reordered"]:
            order = ", ".join(str(int(index) + 1) for index in prep["permutation"])
            print(f"Đổi thứ tự phương trình thành ({order}).")
            print_matrix("A'", a, precision)
            print_matrix("b'", b, precision)
        else:
            print("Không đổi thứ tự phương trình.")
        print("Lý do:", prep["reason"])

        print("\nChéo trội hàng:")
        for i in range(n):
            diagonal_abs = abs(a[i, i])
            off_sum = float(np.sum(np.abs(a[i]))) - diagonal_abs
            relation = (
                ">"
                if diagonal_abs > off_sum
                else ("=" if abs(diagonal_abs - off_sum) <= ZERO_TOL else "<")
            )
            print(
                f"  i={i + 1}: |a_ii|={diagonal_abs:.{precision}g} {relation} "
                f"Σ_(j≠i)|a_ij|={off_sum:.{precision}g}"
            )
        print("Kết luận:", dominance_kind(analysis["row_margins"]))

        print("\nChéo trội cột:")
        for j in range(n):
            diagonal_abs = abs(a[j, j])
            off_sum = float(np.sum(np.abs(a[:, j]))) - diagonal_abs
            relation = (
                ">"
                if diagonal_abs > off_sum
                else ("=" if abs(diagonal_abs - off_sum) <= ZERO_TOL else "<")
            )
            print(
                f"  j={j + 1}: |a_jj|={diagonal_abs:.{precision}g} {relation} "
                f"Σ_(i≠j)|a_ij|={off_sum:.{precision}g}"
            )
        print("Kết luận:", dominance_kind(analysis["col_margins"]))

        print("\nKẾT LUẬN ĐIỀU KIỆN HỘI TỤ:")
        if analysis["row_dom"]:
            print("  A chéo trội hàng nghiêm ngặt ⇒ Gauss–Seidel hội tụ với mọi x^(0).")
            print("  Đã đủ điều kiện nên không cần xét SPD, Sassenfeld hay ||T||∞ để kết luận hội tụ.")
        elif analysis["col_dom"]:
            print("  A chéo trội cột nghiêm ngặt ⇒ Gauss–Seidel hội tụ với mọi x^(0).")
            print("  Đã đủ điều kiện nên không cần xét các tiêu chuẩn hội tụ khác.")
        else:
            print("  A không chéo trội hàng và cũng không chéo trội cột.")
            print("  Chéo trội chỉ là điều kiện đủ, không phải điều kiện cần; vì vậy xét lần lượt:")
            if analysis["spd"]:
                print("\n  1) Tiêu chuẩn SPD:")
                print("     A=A^T và phân tích A=L·D·L^T có mọi d_i>0.")
                print_matrix("L", analysis["spd_data"]["L"], precision)
                print_matrix("diag(D)", analysis["spd_data"]["D"], precision)
                print("     ⇒ A đối xứng xác định dương, nên định lý Gauss–Seidel bảo đảm hội tụ.")
                print("     Đã có chứng nhận SPD nên không cần dùng các hệ số sau để kết luận.")
            else:
                print("\n  1) A không có chứng nhận SPD bằng phân tích LDL^T.")
                print("\n  2) Chuẩn ma trận lặp:")
                print("     T=-(D+L_A)^(-1)U_A và q_T=||T||∞=max_i Σ_j|t_ij|.")
                print(f"     q_T={analysis['q_direct']:.{precision}g}.")
                if analysis["q_direct"] < 1:
                    print("     Vì q_T<1, ánh xạ x↦Tx+g là ánh xạ co ⇒ dãy Seidel hội tụ.")
                else:
                    print("     q_T≥1 nên tiêu chuẩn này không kết luận được hội tụ hay phân kỳ.")

                print("\n  3) Tiêu chuẩn Sassenfeld:")
                print("     β_i=[Σ_(j<i)|a_ij|β_j + Σ_(j>i)|a_ij|]/|a_ii|,")
                print("     β=max_i β_i.")
                print(
                    "     " + ", ".join(
                        f"β_{i + 1}={value:.{precision}g}"
                        for i, value in enumerate(analysis["beta"])
                    )
                )
                print(f"     β={analysis['q_sassenfeld']:.{precision}g}.")
                if analysis["q_sassenfeld"] < 1:
                    print("     Vì β<1, tiêu chuẩn Sassenfeld bảo đảm Gauss–Seidel hội tụ.")
                else:
                    print("     β≥1 nên Sassenfeld cũng không đưa ra kết luận.")

                if analysis["column_data"] is not None and analysis["column_data"]["valid"]:
                    data = analysis["column_data"]
                    print("\n  4) Chuẩn 1 có trọng số sau đổi biến y_i=a_ii·x_i:")
                    print("     ℓ_j là tổng hệ số phía dưới, u_j là tổng hệ số phía trên của cột j;")
                    print("     w_j=1-ℓ_j và q_w=max_j(u_j/w_j).")
                    print(f"     q_w={data['q']:.{precision}g}<1 ⇒ ánh xạ co trong chuẩn ||·||_w, nên hội tụ.")
                elif analysis["q_direct"] >= 1 and analysis["q_sassenfeld"] >= 1:
                    print("\n  Không tiêu chuẩn nào ở trên chứng nhận hội tụ.")
                    print("  Phép lặp vẫn tính được vì a_ii≠0, nhưng chỉ là thử số và không được khẳng định hội tụ.")

        print("\nPHẦN 3. CÔNG THỨC LẶP")
        print("Phân tách A=D+L_A+U_A:")
        print("  D: phần đường chéo của A; L_A: phần tam giác dưới; U_A: phần tam giác trên.")
        print_matrix("D", analysis["D"], precision)
        print_matrix("L_A", analysis["L_A"], precision)
        print_matrix("U_A", analysis["U_A"], precision)
        print_matrix("T=-(D+L_A)^(-1)U_A", analysis["T"], precision)
        print_matrix("g=(D+L_A)^(-1)b", analysis["g"], precision)
        print("Dạng ma trận: x^(k+1)=T·x^(k)+g.")
        print("  T là ma trận lặp, g là vector hằng; cả hai chỉ phụ thuộc A và b.")

        if analysis["variable"] == "y":
            data = analysis["column_data"]
            print("\nDo dùng nhánh chéo trội cột, đặt y_i=a_ii*x_i.")
            print("Hệ tương đương: A D^(-1)y=b và y=Cy+b,")
            print("trong đó C=I-A D^(-1).")
            print_matrix("C", data["C"], precision)
            print("ell_j:", ", ".join(f"{v:.{precision}g}" for v in data["ell"]))
            print("u_j:", ", ".join(f"{v:.{precision}g}" for v in data["u"]))
            print(
                "w_j=1-ell_j:", ", ".join(f"{v:.{precision}g}" for v in data["weights"])
            )
            print(f"q=max_j u_j/w_j={data['q']:.{precision}g}<1.")
            print("Chuẩn dùng: ||z||_w=Σ_j w_j|z_j|.")
            if stop_mode == "apriori":
                print("Chặn tiên nghiệm đã chọn:")
                print("  E_k ≤ s·q^k/(1-q)·||y^(1)-y^(0)||_w.")
            else:
                print("Chặn hậu nghiệm đã chọn:")
                print(
                    "  ||x^(k)-x*||_∞ ≤ [1/min_j(w_j|a_jj|)]·q/(1-q)·||y^(k)-y^(k-1)||_w."
                )
        elif theory:
            if analysis["row_dom"]:
                print("\nA đã chéo trội hàng nên hội tụ đã được bảo đảm.")
                print(
                    f"Để lập chặn sai số, dùng q=||T||∞={analysis['q_direct']:.{precision}g}<1; "
                    "q ở đây dùng cho công thức sai số, không phải xét thêm điều kiện hội tụ."
                )
            else:
                print("\nVì ||T||∞<1, phép lặp là ánh xạ co.")
            if stop_mode == "apriori":
                print("Chặn tiên nghiệm đã chọn:")
                print("  ||x^(k)-x*||_∞ ≤ q^k/(1-q)·||x^(1)-x^(0)||_∞.")
            else:
                print("Chặn hậu nghiệm đã chọn:")
                print("  ||x^(k)-x*||_∞ ≤ q/(1-q)·||x^(k)-x^(k-1)||_∞.")
        elif analysis["spd"]:
            print(
                "\nSPD bảo đảm dãy Seidel hội tụ, nhưng bản này không giả tạo một chặn"
                " sai số ∞ khi chưa có hằng số thích hợp."
            )
        else:
            print(
                "\nChưa có điều kiện đủ hoặc chặn co để bảo đảm hội tụ với mọi x^(0)."
            )

        print("\nCông thức Seidel tổng quát theo từng ẩn:")
        print("  x_i^(k+1) = [b_i - Σ_(j=1..i-1)a_ij·x_j^(k+1)")
        print("                         - Σ_(j=i+1..n)a_ij·x_j^(k)] / a_ii.")
        print("  Các x_j^(k+1), j<i vừa tính trong vòng hiện tại được dùng ngay;")
        print("  các x_j^(k), j>i chưa cập nhật nên dùng giá trị của vòng trước.")
        print("\nThay số vào từng công thức:")
        for i in range(n):
            lower_terms = " ".join(
                f"-({a[i, j]:.{precision}g})x_{j + 1}^(k+1)" for j in range(i)
            )
            upper_terms = " ".join(
                f"-({a[i, j]:.{precision}g})x_{j + 1}^(k)" for j in range(i + 1, n)
            )
            terms = " ".join(item for item in (lower_terms, upper_terms) if item)
            print(
                f"  x_{i + 1}^(k+1)=({b[i]:.{precision}g} {terms})/({a[i, i]:.{precision}g})"
            )

        print("\nPHẦN 4. BẢNG LẶP")
        print("Ký hiệu trong bảng:")
        print("  ||Δx||∞ = ||x^(k)-x^(k-1)||∞: độ thay đổi giữa hai vòng liên tiếp.")
        print("  r=b-Ax^(k), ||r||∞ là chuẩn phần dư (không đồng nhất với sai số nghiệm).")
        print("  eta=||r||∞/(||A||∞·||x^(k)||∞+||b||∞): phần dư tương đối.")
        print("  E_k: chặn trên lý thuyết của ||x^(k)-x*||∞ theo chế độ đã chọn.")
        width = max(12, precision + 8)
        error_header = "E_k tiên nghiệm" if stop_mode == "apriori" else "E_k hậu nghiệm"
        status_width = 12
        header = f"| {'k':>4} |" + "".join(
            f" {('x_' + str(i + 1)):>{width}} |" for i in range(n)
        )
        header += (
            f" {'||Δx||∞':>{width}} | {'||r||∞':>{width}}"
            f" | {'eta':>{width}} | {error_header:>{width}} | {'trạng thái':>{status_width}} |"
        )
        border = "+" + "-" * (len(header) - 2) + "+"
        print(border)
        print(header)
        print(border)
        residual0 = vector_norm_inf(b - a @ x)
        eta0 = relative_residual(a, x, b)
        print(
            f"| {0:4d} |"
            + "".join(
                f" {format_table_number(value, precision):>{width}} |" for value in x
            )
            + f" {'-':>{width}} | {residual0:{width}.{precision}e}"
            f" | {eta0:{width}.{precision}e} | {'-':>{width}} | {'khởi tạo':>{status_width}} |"
        )
        if show_y and analysis["variable"] == "y":
            print_matrix("y^(0)", y, precision)

    xs = [x.copy()]
    residuals = [vector_norm_inf(b - a @ x)]
    converged = False
    certified = False
    numerical_stop = False
    fixed_completed = fixed_iterations == 0
    reason = ""
    error_bound = math.nan
    apriori_iterations = None
    first_difference = None
    first_scale = 1.0
    step_inf = 0.0
    k = 0

    if residuals[0] == 0:
        converged = True
        certified = True
        reason = "x^(0) thỏa Ax=b trong số học máy."

    loop_limit = fixed_iterations if fixed_iterations is not None else max_iter
    if fixed_iterations == 0:
        reason = "Đã thực hiện đúng 0 bước theo yêu cầu."

    for k in range(1, loop_limit + 1):
        old_x = x.copy()
        old_y = y.copy()

        if analysis["variable"] == "y":
            for i in range(n):
                y[i] = (
                    analysis["d"][i]
                    + analysis["L"][i, :i] @ y[:i]
                    + analysis["U"][i, i + 1 :] @ old_y[i + 1 :]
                )
            x = y / diagonal
        else:
            for i in range(n):
                lower_value = a[i, :i] @ x[:i]
                upper_value = a[i, i + 1 :] @ old_x[i + 1 :]
                x[i] = (b[i] - lower_value - upper_value) / a[i, i]
            y = x.copy()

        if not np.all(np.isfinite(x)):
            reason = "Xuất hiện NaN hoặc vô cùng."
            break
        if vector_norm_inf(x) > HUGE_VALUE:
            reason = "Giá trị lặp tăng quá lớn."
            break

        step_inf = vector_norm_inf(x - old_x)
        residual = vector_norm_inf(b - a @ x)
        eta = relative_residual(a, x, b)

        if theory:
            if theory["kind"] == "x_inf":
                difference = step_inf
                scale = 1.0
            else:
                difference = weighted_one_norm(y - old_y, theory["weights"])
                scale = theory["scale_to_x_inf"]
            error_bound = scale * theory["coefficient"] * difference
            if first_difference is None:
                first_difference = difference
                first_scale = scale
                apriori_iterations = estimate_apriori_iterations(
                    theory["q"], first_difference, first_scale, epsilon
                )
            if stop_mode == "apriori":
                error_bound = (
                    first_scale
                    * theory["q"] ** k
                    / (1 - theory["q"])
                    * first_difference
                )
        else:
            error_bound = math.nan

        state = "tiếp tục"
        posteriori_reached = stop_mode == "posteriori" and error_bound <= epsilon
        apriori_reached = (
            stop_mode == "apriori"
            and apriori_iterations is not None
            and k >= apriori_iterations
        )
        if fixed_iterations is None and theory and (posteriori_reached or apriori_reached):
            converged = True
            certified = True
            reason = "Chặn hậu nghiệm không vượt quá epsilon."
            state = "đạt chặn"
            if apriori_reached:
                reason = "Chặn tiên nghiệm không vượt quá epsilon."
        elif fixed_iterations is None and not theory:
            scaled_step = epsilon * max(1.0, vector_norm_inf(x))
            if step_inf <= scaled_step and eta <= residual_tolerance:
                converged = True
                numerical_stop = True
                reason = (
                    "Đạt tiêu chuẩn dừng số (bước lặp tương đối và phần dư tương đối); "
                    "không coi đây là chặn sai số nghiệm."
                )
                state = "đạt số"

        if show:
            width = max(12, precision + 8)
            e_text = (
                f"{error_bound:.{precision}e}" if math.isfinite(error_bound) else "N/A"
            )
            print(
                f"| {k:4d} |"
                + "".join(
                    f" {format_table_number(value, precision):>{width}} |" for value in x
                )
                + f" {step_inf:{width}.{precision}e} | {residual:{width}.{precision}e}"
                f" | {eta:{width}.{precision}e} | {e_text:>{width}} | {state:>{status_width}} |"
            )
            if show_y and analysis["variable"] == "y":
                print_matrix(f"y^({k})", y, precision)
            if k == 1 and theory and stop_mode == "apriori":
                print("  Chặn tiên nghiệm:")
                print("    E_k <= s·q^k/(1-q)·||z^(1)-z^(0)||,")
                print(
                    f"    q={theory['q']:.{precision}g}, s={first_scale:.{precision}g}."
                )
                if apriori_iterations is not None:
                    print(
                        f"    Suy ra k >= {apriori_iterations} để chặn không vượt epsilon."
                    )

        xs.append(x.copy())
        residuals.append(residual)
        if converged and fixed_iterations is None:
            break
        diagnosis = _diagnose(xs, residuals, epsilon)
        if fixed_iterations is None and diagnosis:
            reason = diagnosis
            break
    else:
        if fixed_iterations is not None:
            fixed_completed = True
            reason = f"Đã thực hiện đúng {fixed_iterations} bước."
        elif not converged:
            reason = "Hết max_iter nhưng chưa đạt điều kiện dừng."

    final_residual_vector = b_original - a_original @ x
    final_residual = vector_norm_inf(final_residual_vector)
    final_eta = relative_residual(a_original, x, b_original)

    info = {
        **prep,
        "converged": converged,
        "certified": certified,
        "numerical_stop": numerical_stop,
        "fixed_iterations_completed": fixed_completed,
        "iterations": k,
        "error_bound": error_bound,
        "residual": final_residual,
        "relative_residual": final_eta,
        "reason": reason,
        "apriori_iterations": apriori_iterations,
        "iteration_method": analysis["method"],
        "theory": theory,
        "q": theory["q"] if theory else math.nan,
    }

    if show:
        print(border)
        print("\nPHẦN 5. ĐIỀU KIỆN DỪNG VÀ KẾT QUẢ")
        if fixed_completed:
            print(reason)
            print(
                "Đây là giá trị sau đúng số bước yêu cầu, không tự động đồng nghĩa đã hội tụ."
            )
        elif certified:
            print(reason)
            print(
                f"E_k={error_bound:.{precision}e} <= epsilon={epsilon:.{precision}e}."
            )
        elif numerical_stop:
            print(reason)
        else:
            print("Chưa xác nhận đạt yêu cầu:", reason)
        print_matrix(f"x^({k})", x, precision)
        print_matrix("A x^(k)", a_original @ x, precision)
        print_matrix("b-A x^(k)", final_residual_vector, precision)
        print(f"||b-Ax^(k)||_∞={final_residual:.{precision}e}")
        print(f"eta={final_eta:.{precision}e}")
        if math.isfinite(error_bound):
            print(f"Chặn sai số nghiệm theo chuẩn ∞: E_k={error_bound:.{precision}e}")
        else:
            print("Không có chặn sai số nghiệm theo chuẩn ∞ trong nhánh hiện tại.")

    return x, info


# ============================================================================
# NHIỀU VẾ PHẢI VÀ NGHỊCH ĐẢO
# ============================================================================


def solve_multiple_rhs(
    a,
    big_b,
    x0=None,
    epsilon=1e-6,
    max_iter=500,
    precision=6,
    auto_reorder=True,
    show=True,
    fixed_iterations=None,
    use_inverse_bound=False,
    residual_tolerance=None,
    stop_mode="posteriori",
):
    del use_inverse_bound
    a = np.asarray(a, dtype=float)
    big_b = np.asarray(big_b, dtype=float)
    validate_system(a)
    if big_b.ndim != 2 or big_b.shape[0] != len(a) or not np.all(np.isfinite(big_b)):
        raise ValueError("B sai kích thước hoặc chứa NaN/vô cùng.")
    initial = np.zeros(len(a)) if x0 is None else np.asarray(x0, dtype=float)
    if initial.shape != (len(a),):
        raise ValueError("x0 sai kích thước.")

    columns = []
    infos = []
    for j in range(big_b.shape[1]):
        if show:
            print(f"\n{'#' * 28} VẾ PHẢI {j + 1}/{big_b.shape[1]} {'#' * 28}")
        solution, info = gauss_seidel(
            a,
            big_b[:, j],
            initial,
            epsilon,
            max_iter,
            precision,
            auto_reorder,
            show,
            fixed_iterations,
            residual_tolerance=residual_tolerance,
            stop_mode=stop_mode,
        )
        columns.append(solution)
        infos.append(info)
    result = np.column_stack(columns)
    if show:
        print_matrix("Ma trận nghiệm X", result, precision)
        print(f"||B-AX||_∞={matrix_norm_inf(big_b - a @ result):.{precision}e}")
    return result, infos


def solve_inverse(
    a,
    x0=None,
    epsilon=1e-6,
    max_iter=500,
    precision=6,
    auto_reorder=True,
    show=True,
    fixed_iterations=None,
    use_inverse_bound=False,
    residual_tolerance=None,
    stop_mode="posteriori",
):
    del use_inverse_bound
    a = np.asarray(a, dtype=float)
    validate_system(a)
    n = len(a)
    initial = np.zeros(n) if x0 is None else np.asarray(x0, dtype=float)
    inverse, infos = solve_multiple_rhs(
        a,
        np.eye(n),
        initial,
        epsilon,
        max_iter,
        precision,
        auto_reorder,
        show,
        fixed_iterations,
        residual_tolerance=residual_tolerance,
        stop_mode=stop_mode,
    )
    left_error = matrix_norm_inf(a @ inverse - np.eye(n))
    right_error = matrix_norm_inf(inverse @ a - np.eye(n))
    all_converged = all(info["converged"] for info in infos)
    all_certified = all(info["certified"] for info in infos)
    if show:
        print("\nKẾT QUẢ TÌM NGHỊCH ĐẢO")
        print_matrix("A^(-1) gần đúng", inverse, precision)
        print(f"||AA^(-1)-I||_∞={left_error:.{precision}e}")
        print(f"||A^(-1)A-I||_∞={right_error:.{precision}e}")
        if all_certified:
            print("Mọi cột đều đạt chặn sai số lý thuyết.")
        elif all_converged:
            print(
                "Mọi cột đạt tiêu chuẩn dừng số, nhưng không phải cột nào cũng có chặn lý thuyết."
            )
        else:
            print("CẢNH BÁO: ít nhất một cột chưa đạt điều kiện dừng.")
    return inverse, {
        "columns": infos,
        "left_error": left_error,
        "right_error": right_error,
        "converged": all_converged,
        "certified": all_certified,
    }


# ============================================================================
# GIAO DIỆN
# ============================================================================


def print_exam_overview(task_choice):
    print("\n" + "=" * 92)
    print("THUẬT TOÁN GAUSS–SEIDEL")
    print("=" * 92)
    print("Input:")
    if task_choice == "1":
        print("  • Ma trận vuông A, vector b, vector đầu x^(0).")
    elif task_choice == "2":
        print("  • Ma trận vuông A, ma trận nhiều vế phải B và vector đầu x^(0).")
    else:
        print("  • Ma trận khả nghịch A; giải lần lượt A x_j=e_j để ghép A^(-1).")
    print("  • Sai số epsilon hoặc số bước lặp k theo yêu cầu đề bài.")
    print("Output:")
    print("  • Nghiệm gần đúng, bảng lặp, chặn sai số và phần dư kiểm tra.")
    print("Các bước cho một vế phải:")
    print("  B1. Phân tách A=D+L+U và kiểm tra điều kiện hội tụ.")
    print("  B2. Với i=1,...,n, tính tuần tự:")
    print("      x_i^(k+1)=[b_i-Σ_(j<i)a_ij x_j^(k+1)-Σ_(j>i)a_ij x_j^(k)]/a_ii.")
    print("  B3. Dùng ngay các thành phần mới x_j^(k+1), j<i.")
    print("  B4. Đánh giá sai số, phần dư r^(k)=b-Ax^(k), rồi kiểm tra dừng.")


def main():
    global DISPLAY_FRACTIONS
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")

    print("GAUSS–SEIDEL – BÀI GIẢI CHI TIẾT")
    print("1. Giải hệ Ax=b")
    print("2. Giải nhiều vế phải AX=B")
    print("3. Tìm A^(-1) bằng cách giải AX=I")
    print("0. Thoát")
    choice = input("Chọn [1]: ").strip() or "1"
    if choice == "0":
        return
    if choice not in {"1", "2", "3"}:
        print("Lựa chọn không hợp lệ.")
        return

    print_exam_overview(choice)

    try:
        n = read_int("Cấp ma trận n = ", minimum=1)
        a = read_matrix(n, n, "A")
        auto_reorder = input(
            "Tự động đổi hàng nếu có lợi? [C/k]: "
        ).strip().lower() not in {"k", "khong", "không", "n", "no"}
        precision = read_int("Số chữ số sau dấu phẩy [7] = ", minimum=0, default=7)
        DISPLAY_FRACTIONS = input("In phân số gần đúng? [k/C]: ").strip().lower() in {
            "c",
            "co",
            "có",
            "y",
            "yes",
        }

        print("Chế độ dừng:")
        print("1. Chặn sai số hậu nghiệm")
        print("2. Chặn sai số tiên nghiệm")
        print("3. Số chữ số thập phân chính xác")
        print("4. Thực hiện đúng k bước")
        stop_choice = input("Chọn [1]: ").strip() or "1"
        if stop_choice not in {"1", "2", "3", "4"}:
            raise ValueError("Chế độ dừng không hợp lệ.")
        stop_mode = "posteriori"
        if stop_choice in {"1", "2"}:
            epsilon = read_float("epsilon [1e-6] = ", positive=True, default=1e-6)
            max_iter = read_int("max_iter [500] = ", minimum=1, default=500)
            fixed_iterations = None
            residual_tolerance = epsilon
            stop_mode = "posteriori" if stop_choice == "1" else "apriori"
        elif stop_choice == "3":
            exact_digits = read_int("Số chữ số thập phân chính xác d = ", minimum=0)
            epsilon = 0.5 * 10.0 ** (-exact_digits)
            print(f"Chọn epsilon = 0.5·10^(-{exact_digits}) = {epsilon:.6e}.")
            max_iter = read_int("max_iter [500] = ", minimum=1, default=500)
            fixed_iterations = None
            residual_tolerance = epsilon
        else:
            fixed_iterations = read_int("Số bước k = ", minimum=0)
            epsilon = read_float(
                "epsilon để tham khảo [1e-6] = ", positive=True, default=1e-6
            )
            max_iter = max(1, fixed_iterations)
            residual_tolerance = epsilon

        if choice == "1":
            b = read_vector(n, f"Nhập b ({n} phần tử): ")
            x0 = read_vector(n, f"Nhập x^(0) ({n} phần tử, Enter=0): ", default=0.0)
            gauss_seidel(
                a,
                b,
                x0,
                epsilon,
                max_iter,
                precision,
                auto_reorder,
                fixed_iterations=fixed_iterations,
                residual_tolerance=residual_tolerance,
                stop_mode=stop_mode,
            )
        elif choice == "2":
            m = read_int("Số vế phải m = ", minimum=1)
            big_b = read_matrix(n, m, "B")
            x0 = read_vector(n, f"x^(0) dùng chung ({n} số, Enter=0): ", default=0.0)
            solve_multiple_rhs(
                a,
                big_b,
                x0,
                epsilon,
                max_iter,
                precision,
                auto_reorder,
                fixed_iterations=fixed_iterations,
                residual_tolerance=residual_tolerance,
                stop_mode=stop_mode,
            )
        else:
            x0 = read_vector(n, f"x^(0) dùng chung ({n} số, Enter=0): ", default=0.0)
            solve_inverse(
                a,
                x0,
                epsilon,
                max_iter,
                precision,
                auto_reorder,
                fixed_iterations=fixed_iterations,
                residual_tolerance=residual_tolerance,
                stop_mode=stop_mode,
            )
    except (ValueError, ArithmeticError) as exc:
        print(f"\nKhông thể thực hiện: {exc}")
    except (EOFError, KeyboardInterrupt):
        print("\nĐã dừng chương trình.")


if __name__ == "__main__":
    try:
        main()
    except (EOFError, KeyboardInterrupt):
        print("\nĐã dừng chương trình; không có dữ liệu đầu vào đầy đủ.")
